<?php
require_once 'classes/DB.php';
//Уничтожение переменной сессии
unset($_SESSION['logged_user']);
//Редирект на главную страницу
echo "<script>
        location.replace('index.php');
        </script>";
?>