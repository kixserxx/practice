<?php
require_once 'classes/DB.php';
require_once 'classes/Inter.php';
require_once 'classes/User.php';
require_once 'classes/Order.php';
?>
<meta charset="utf-8">
<?php
$data = $_POST;
$db = new DB;

/* Обработка входа */
if (isset($data['do_login'])) {
	
    $query = "SELECT * FROM user WHERE user_login='{$data['user_login']}'";
    $result = mysqli_query($db->con, $query);
    
    if($result){

        $row = mysqli_fetch_row($result);
        $user = new User($row[1], $row[2], $row[3], $row[4]);
    
        if(password_verify($data['user_password'], $user->user_password))  
        {
            $_SESSION["logged_user"] = serialize($user);  
        }  
        else  
        {  
            $message = $db->error;  
            echo $message;
        }
    }
}


Inter::head();

/* Если пользователь не авторизован, то вывести форму входа */
if(!isset($_SESSION['logged_user'])){
    Inter::loginForm();
}

/* Работа с вошедшим пользователем*/
else{
    //Обработка нажатия Удалить
    if(isset($_GET['delete']) && unserialize($_SESSION['logged_user'])->user_role=='CUSTOMER'){
        Order::delete($_GET['delete']);
    }
    
    //Обработка нажатия Добавить заказ
    if(isset($_POST['push']) && isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role=="CUSTOMER"){
        $order = new Order($_POST['service'], unserialize($_SESSION['logged_user'])->getId(), $_POST['employees'], $_POST['date']);
        $order->add();
    }
    
    //Если аторизованный пользователь - клиент, то вывести форму добавления заказа
    if(unserialize($_SESSION['logged_user'])->user_role=="CUSTOMER")
        Order::displayForm();
        
    //Вывести таблицу заказов для пользователя
    Order::displayTable();
}
?>