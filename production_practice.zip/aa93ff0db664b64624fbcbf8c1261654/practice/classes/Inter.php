<?php
class Inter{
    //Подключить верхнюю часть страницы
    public static function head(){
        include (realpath('./inter_elements/head.php'));
    }
    
    //Подключить меню
    public static function menu(){
        include (realpath('./inter_elements/head.php'));
    }
    
    //Подключить меню
    public static function loginForm(){
        include (realpath('./inter_elements/login_form.php'));
    }
    
    //Подключить форму регистрации
    public static function regForm(){
        include (realpath('./inter_elements/registration_form.php'));
    }
    
    //Метод изменения ссылки для сортировки
    public static function sort_link_th($title, $a, $b) {
	    $sort = @$_GET['sort'];
    	if ($sort == $a) {
    		return '<a class="active" href="?sort=' . $b . '">' . $title . ' <i>▲</i></a>';
    	} elseif ($sort == $b) {
    		return '<a class="active" href="?sort=' . $a . '">' . $title . ' <i>▼</i></a>';  
    	} else {
    		return '<a href="?sort=' . $a . '">' . $title . '</a>';  
    	}
    }
}
?>