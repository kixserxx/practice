<?php
include_once ('DB.php');
class User {
    public $user_name;
    public $user_role;
    public $user_login;
    public $user_password;
    
    public function __construct($user_name, $user_role, $user_login, $user_password){
        $db = new DB;
        $this->user_name = $db->con->real_escape_string($user_name);
        $this->user_role = $db->con->real_escape_string($user_role);
        $this->user_login = $db->con->real_escape_string($user_login);
        $this->user_password = $db->con->real_escape_string($user_password);
    }
    
    //Получить id пользователя
    public function getId(){
        $db = new DB;
        $a=$db->getQueryResult("SELECT user_id from `user` where user_login='".$this->user_login."'");
        $row = mysqli_fetch_row($a);
        return $row[0];
    }
    
    //Добавить пользователя в БД
    public function add(){
        $db = new DB;
        $result = $db->getQueryResult("SELECT COUNT(*) FROM user WHERE user_login='{$this->user_login}'");
        $employeesCount = mysqli_fetch_array($result)[0];
        if($employeesCount > 0)
            echo '<script language="javascript">alert("Пользователь с таким логином уже есть!")</script>';
        else
            $db->makeQuery("INSERT INTO `user`(`user_name`, `user_role`, `user_login`, `user_password`) VALUES ('{$this->user_name}','{$this->user_role}', '{$this->user_login}', '".password_hash($this->user_password, PASSWORD_DEFAULT)."')");
    }
    
    //Удалить пользователя из БД
    public static function delete($id){
        $db = new DB();
        $db->makeQuery("DELETE FROM `user` WHERE user_id={$id}");
    }
    
    //Изменить сведения о пользователе
    public static function change($id, $user_name, $user_login, $user_password){
        $db = new DB;
        $dop = "";
        if(trim($user_password) != '')
            $dop = ", user_password='".password_hash($user_password, PASSWORD_DEFAULT)."'";
        $db->makeQuery("UPDATE `user` SET user_name='{$user_name}', user_login='{$user_login}'".$dop." WHERE user_id=".$id);
    }
    
    //Отобразить форму для изменения информации о пользователе. Пользователь может изменить информацию только о себе
    public static function displayForm(){
        $db = new DB;
        echo '<link href="css/edit_form.css" rel="stylesheet">';
            echo '<div class="edit-page">
                <div class="edit-form">
                        <form method="post" class="login-form">';
                            echo '
                            <label>ФИО</label>
                            <input type="text" name="user_name"';
                            echo ' value="'.unserialize($_SESSION['logged_user'])->user_name.'"';
                            echo '>';
                            
                            echo '
                            <label>Логин</label>
                            <input type="text" name="user_login"';
                            echo ' value="'.unserialize($_SESSION['logged_user'])->user_login.'"';
                            echo '>';
                            
                            echo '
                            <label>Пароль</label>
                            <input type="password" name="user_password">';
                            
                            echo '<label>Роль: ';
                            if(unserialize($_SESSION['logged_user'])->user_role=="CUSTOMER")
                                echo "Заказчик";
                            else
                                echo "Дизайнер";
                            echo'</label><br><br>';

                            if(isset($_SESSION['logged_user'])){
                                echo '<button type="submit" name="push">';
                                echo "Изменить";
                                echo '</button>';
                            }
                        echo'
                        </form>
                    </div>
            </div>
            ';
    }
    
    //Вывести таблицу дизайнеров
    public static function displayDesignerTable(){
        $sort_list = array(
        	'user_name_asc'  => '`user_name`',
        	'user_name_desc' => '`user_name` DESC'
        );
        
        //Сортировка в зависимости от параметра
        $sort = @$_GET['sort'];
        if (array_key_exists($sort, $sort_list)) {
        	$sort_sql = $sort_list[$sort];
        } else {
        	$sort_sql = reset($sort_list);
        }
        
        $db = new DB;
        $sql = "SELECT user_name FROM `user` WHERE user_role='EMPLOYEE' ORDER BY {$sort_sql}";
        $res_data = $db->getQueryResult($sql);
        
        echo '<link href="css/table.css" rel="stylesheet">';
        echo '<table border=1 class="db_table">
            <thead>
                <tr>
                    <th>';
                    echo Inter::sort_link_th('ФИО', 'user_name_asc', 'user_name_desc');
                    echo'</th>';
                echo '</tr>
            </thead>';
        
        if ($res_data->num_rows > 0) {
            while ($row = $res_data->fetch_assoc()) {
                echo "<tr>
                    <td>".$row["user_name"]."</td>";
                echo "</tr>";
            }
        }
        echo '</table>';
    }
}
?>