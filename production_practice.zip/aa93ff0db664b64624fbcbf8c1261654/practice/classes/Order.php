<?php
require_once 'classes/DB.php';
require_once 'classes/User.php';

class Order{
    public $order_service_id;
    public $order_user_customer_id;
    public $order_user_employee_id;
    public $order_date;

    public function __construct($order_service_id, $order_user_customer_id, $order_user_employee_id, $order_date){
        $db =new DB();
        $this->order_service_id = $db->con->real_escape_string($order_service_id);
        $this->order_user_customer_id = $db->con->real_escape_string($order_user_customer_id);
        $this->order_user_employee_id = $db->con->real_escape_string($order_user_employee_id);
        $this->order_date = $db->con->real_escape_string($order_date);
    }
    
    //Добавить заказ в БД
    public function add(){
        $db = new DB;
        if(!$db->getQueryResult("INSERT INTO `order_second`(`order_service_id`, `order_user_customer_id`, `order_date`, `order_user_employee_id`) VALUES
                                 ({$this->order_service_id}, {$this->order_user_customer_id}, '{$this->order_date }', '{$this->order_user_employee_id}');")){
            echo "Ошибка!";
        }
    }
    
    //Удалить заказ ид БД
    public static function delete($id){
            $db = new DB;
            $db->makeQuery("DELETE FROM `order_second` WHERE `order_id`={$id};");
    }
    
    //Изменить заказ
    public static function change($id,
                                  $order_service_id,
                                  $order_user_customer_id,
                                  $order_user_employee_id,
                                  $order_date){
            $db = new DB;
            $db->makeQuery("UPDATE `order_second` SET `order_service_id`={$orders_service_id}, `order_date`='{$order_date}', `order_customer_id`={$orders_customer_id}, `order_employee_id`={$order_employee_id} WHERE order_id={$id};");
    }
    
    //Вывести форму добавления заказа
    public static function displayForm(){
            $db = new DB;
            if(isset($_GET['edit'])){
                $product = mysqli_fetch_array($db->getQueryResult("SELECT * FROM order_second WHERE order_id={$_GET['edit']}"));
            }
            echo '<link href="css/edit_form.css" rel="stylesheet">';
            echo '<div class="edit-page">
                <div class="edit-form">
                        <form method="post" class="login-form">';
                            echo '
                            <label>Исполнитель</label><br><br>
                            <select name="employees">';
                            $result = $db->getQueryResult("SELECT * FROM user WHERE user_role='EMPLOYEE'");
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {

                                        echo "<option";
                                        if($row['user_id'] == $product['order_employee_id'])
                                            echo " selected='selected' ";
                                        echo " value=".$row["user_id"].">".$row["user_name"]."</option>";

                                }
                            }
                            echo '</select>';

                            echo '
                            <label>Дата</label><br><br>
                            <input type="date" name="date"';
                            if(isset($_GET['edit'])){
                                echo ' value="'.$product["order_date"].'"';
                            }
                            echo '>';

                            echo '
                            <label>Услуга</label><br><br>
                            <select name="service">';
                            $result = $db->getQueryResult("SELECT * FROM service");
                            if ($result->num_rows > 0) {
                                while ($row = $result->fetch_assoc()) {
                                    echo "<option";
                                    if($row['service_id'] == $product['order_service_id'])
                                        echo " selected='selected' ";
                                    echo " value=".$row["service_id"].">".$row["service_name"]."</option>";
                                }
                            }
                            echo '</select>';

                            if(isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role=="CUSTOMER"){
                                echo '<button type="submit" name="push">';
                                echo "Добавить";
                                echo '</button>';
                            }
                            /*echo '<br/><br/>';
                            echo '<button type="submit" name="search">Поиск</button>';
                            if(isset($_GET['edit']) || isset($_POST['search']))
                                echo '<a href="?add=new">Очистить форму</a>';*/
                        echo'
                        </form>
                    </div>
            </div>
            ';
        }
    
    //Вывести таблицу заказов
    public static function displayTable(){
        $sort_list = array(
            'order_date_asc'  => '`order_date`',
            'order_date_desc' => '`order_date` DESC',
            'user_emp_name_asc'   => '`user_emp_name`',
            'user_emp_name_desc'  => '`user_emp_name` DESC',
            'user_cust_name_asc'   => '`user_cust_name`',
            'user_cust_name_desc'  => '`user_cust_name` DESC',
            'service_name_asc'  => '`service_name`',
            'service_name_desc' => '`service_name` DESC',
            'user_cust_name_asc'  => '`user_cust_name`',
            'user_cust_name_desc' => '`user_cust_name` DESC'
        );
        
        //Сортировка в зависимости от параметра
        $sort = @$_GET['sort'];
        if (array_key_exists($sort, $sort_list)) {
           	$sort_sql = $sort_list[$sort];
        } else {
           	$sort_sql = reset($sort_list);
        }
            
        $db = new DB;
        
        //Вывод таблицы в зависимости от роли пользователя
        //Если пользователь - клиент
        if(unserialize($_SESSION['logged_user'])->user_role == 'CUSTOMER'){
            $sql = "SELECT order_id, service_name, user_name as user_emp_name, order_date FROM order_second INNER JOIN `service` on order_service_id=service_id INNER JOIN `user` ON order_user_employee_id=user_id where order_user_customer_id=".unserialize($_SESSION['logged_user'])->getId()." ORDER BY $sort_sql";
            $res_data = $db->getQueryResult($sql);
            echo '<link href="css/table.css" rel="stylesheet">';
            echo '<table border=1 class="db_table">
                    <thead>
                        <tr>
                            <th>';
                            echo Inter::sort_link_th('Исполнитель', 'user_emp_name_asc', 'user_emp_name_desc');
                            echo'</th>
                            <th>';
                            echo Inter::sort_link_th('Услуга', 'service_name_asc', 'service_name_desc');
                            echo'</th>
                            <th>';
                            echo Inter::sort_link_th('Дата', 'order_date_asc', 'order_date_desc');
                            echo'</th>';
                            if(isset($_SESSION['logged_user'])){
                                echo '<th></th>';
                            }
                        echo '</tr>
                    </thead>';
            if ($res_data->num_rows > 0) {
                while ($row = $res_data->fetch_assoc()) {
                    echo "<tr>
                        <td>".$row["user_emp_name"]."</td>
                        <td>".$row["service_name"]."</td>
                        <td>".$row["order_date"]."</td>";
                        if(isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role == 'CUSTOMER'){
                            echo "<td><a href='?delete={$row['order_id']}'>Удалить</a></td>";
                        }
                    echo "</tr>";
                }
            }
            echo '</table>';
        }
        
        //Если пользователь - дизайнер
        else if(unserialize($_SESSION['logged_user'])->user_role == 'EMPLOYEE'){
            $sql = "SELECT order_id, service_name, user_name as user_cust_name, order_date FROM order_second INNER JOIN `service` on order_service_id=service_id INNER JOIN `user` ON order_user_customer_id=user_id where order_user_employee_id=".unserialize($_SESSION['logged_user'])->getId()." ORDER BY $sort_sql";
            $res_data = $db->getQueryResult($sql);
            echo '<link href="css/table.css" rel="stylesheet">';
            echo '<table border=1 class="db_table">
                    <thead>
                        <tr>
                            <th>';
                            echo Inter::sort_link_th('Заказчик', 'user_cust_name_asc', 'user_cust_name_desc');
                            echo'</th>
                            <th>';
                            echo Inter::sort_link_th('Услуга', 'service_name_asc', 'service_name_desc');
                            echo'</th>
                            <th>';
                            echo Inter::sort_link_th('Дата', 'order_date_asc', 'order_date_desc');
                            echo'</th>';
                            if(isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role == 'CUSTOMER'){
                                echo '<th></th>';
                            }
                        echo '</tr>
                    </thead>';
            if ($res_data->num_rows > 0) {
                while ($row = $res_data->fetch_assoc()) {
                    echo "<tr>
                        <td>".$row["user_cust_name"]."</td>
                        <td>".$row["service_name"]."</td>
                        <td>".$row["order_date"]."</td>";
                        if(isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role == 'CUSTOMER'){
                            echo "<td><a href='?delete={$row['order_id']}'>Удалить</a></td>";
                        }
                    echo "</tr>";
                }
            }
            echo '</table>';
        }
    }
}
?>