<?php
include_once ('DB.php');
include_once ('User.php');
class Service{
    public $service_name;
    public $service_price;
    public function __construct($service_name, $service_price){
        $db = new DB;
        $this->service_name = $db->con->real_escape_string($service_name);
        $this->service_price = $db->con->real_escape_string($service_price);
    }
    
    //Добавить услугу в БД
    public function add(){
        $db = new DB;
        $result = $db->getQueryResult("SELECT COUNT(*) FROM service WHERE service_name='{$this->service_name}'");
        $employeesCount = mysqli_fetch_array($result)[0];
        if($employeesCount > 0)
            echo '<script language="javascript">alert("Такая услуга уже есть!")</script>';
        else
            $db->makeQuery("INSERT INTO `service`(`service_name`, `service_price`) VALUES ('{$this->service_name}', {$this->service_price})");
    }
    
    //Удалить услугу из БД
    public static function delete($id){
        $db = new DB();
        $db->makeQuery("DELETE FROM `service` WHERE service_id='{$id}';");
    }
    
    //Изменить услугу
    public static function change($id, $service_name, $service_price){
        $db = new DB;
        $result = $db->getQueryResult("SELECT * FROM service WHERE service_id={$id}");
        $service = mysqli_fetch_array($result);
        if($service['service_name'] == $service_name)
            $db->makeQuery("UPDATE `service` SET `service_name`='{$service_name}', `service_price`={$service_price} WHERE service_id={$id}");
        else{
            $result = $db->getQueryResult("SELECT COUNT(*) FROM service WHERE service_name='{$service_name}'");
            $employeesCount = mysqli_fetch_array($result)[0];
            if($employeesCount > 0)
                echo '<script language="javascript">alert("Такой товар уже есть!")</script>';
            else
                $db->makeQuery("UPDATE `service` SET `service_name`='{$service_name}', `service_price`={$service_price} WHERE service_id={$id}");
        }
    }
    
    //Вывести таблицу услуг
    public static function displayTable(){
        $sort_list = array(
    	    'service_id_asc'   => '`service_id`',
        	'service_id_desc'  => '`service_id` DESC',
        	'service_name_asc'  => '`service_name`',
        	'service_name_desc' => '`service_name` DESC',
        	'service_price_asc'  => '`service_price`',
        	'service_price_desc' => '`service_price` DESC'
        );
        
        //Сортировка в зависимости от параметра
        $sort = @$_GET['sort'];
        if (array_key_exists($sort, $sort_list)) {
        	$sort_sql = $sort_list[$sort];
        } else {
        	$sort_sql = reset($sort_list);
        }
        
        $db = new DB;
        
        //Формирование запроса на поиск
        if(isset($_POST['search']))
            $sql = service::searchQuery()." ORDER BY $sort_sql";
        else
            $sql = "SELECT service_id, service_name, service_price FROM service ORDER BY $sort_sql";
        $res_data = $db->getQueryResult($sql);
        
        echo '<link href="css/table.css" rel="stylesheet">';
        echo '<table border=1 class="db_table">
            <thead>
                <tr>
                    <th>';
                    echo Inter::sort_link_th('№', 'service_id_asc', 'service_id_desc');
                    echo'</th>
                    <th>';
                    echo Inter::sort_link_th('Название', 'service_name_asc', 'service_name_desc');
                    echo'</th><th>';
                    echo Inter::sort_link_th('Цена', 'service_price_asc', 'service_price_desc');
                    echo '</th>';
                    if(isset($_SESSION['logged_user']) && $_SESSION['logged_user'] == 'EMPLOYEE'){
                        echo '<th></th>
                        <th></th>';
                    }
                echo '</tr>
            </thead>';
        
        if ($res_data->num_rows > 0) {
            while ($row = $res_data->fetch_assoc()) {
                echo "<tr>
                    <td>".$row["service_id"]."</td>
                    <td>".$row["service_name"]."</td>
                    <td>".$row["service_price"]."</td>";
                    if(isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role == 'EMPLOYEE'){
                        echo "<td><a href='?delete={$row['service_id']}'>Удалить</a></td>
                        <td><a href='?edit={$row['service_id']}'>Изменить</a></td>";
                    }
                echo "</tr>";
            }
        }
        echo '</table>';
    }
    
    //Вывести форму редактирования и добавления
    public static function displayForm(){
        $db = new DB;
        if(isset($_GET['edit'])){
            $product = mysqli_fetch_array($db->getQueryResult("SELECT * FROM service WHERE service_id={$_GET['edit']}"));
        }
        echo '<link href="css/edit_form.css" rel="stylesheet">';
        echo '<div class="edit-page">
            <div class="edit-form">
                    <form method="post" class="login-form">
                        <label>Услуга</label>
                        <input type="text" name="service_name"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["service_name"].'"';
                        }
                        echo '>';
                        echo '
                        <label>Цена</label>
                        <input type="text" name="service_price"';
                        if(isset($_GET['edit'])){
                            echo ' value="'.$product["service_price"].'"';
                        }
                        echo '>';
                        
                        //Редактировать и добавлять может только дизайнер
                        if(isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role == 'EMPLOYEE'){
                            echo '<button type="submit" name="push">';
                                if(isset($_GET['edit']))
                                    echo "Изменить";
                                else
                                    echo "Добавить";
                            echo '</button>';
                        }
                        echo '<br/><br/>';
                        echo '<button type="submit" name="search">Поиск</button>';
                        if(isset($_GET['edit']) || isset($_POST['search']))
                            echo '<a href="?add=new">Очистить форму</a>';
                    echo'    
                    </form>
                </div>
        </div>
        ';
    }
    
    //Создать запрос на поиск
    public static function searchQuery(){
        $querySearchList = "select service_id, service_name, service_price from service where ";
        $queryAllList = "select service_id, service_name, service_price from service";
        $query = $queryAllList;
        if(trim($_POST['service_name'])!=''){
            if($query == $queryAllList)
                $query .= " where ";
            else
                $query .= " AND ";
            $query .= " service_name LIKE N'%{$_POST['service_name']}%'";
        }
        if(trim($_POST['service_price'])!=''){
            if($query == $queryAllList)
                $query .= " where ";
            else
                $query .= " AND ";
            $query .= " service_price LIKE N'%{$_POST['service_price']}%'";
        }
        
        return $query;
    }
}
?>