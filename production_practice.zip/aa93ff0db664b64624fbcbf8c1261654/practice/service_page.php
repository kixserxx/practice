<?php
require_once 'classes/DB.php';
require_once 'classes/Inter.php';
require_once 'classes/Service.php';
?>

<meta charset="utf-8">

<?php
$data = $_POST;
$db = new DB;

Inter::head();
//Обработка нажатия кнопки удаления. Удалить может только дизайнер
if(isset($_GET['delete']) && isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role=='EMPLOYEE'){
    Service::delete($_GET['delete']);
}

if(isset($_GET['edit']) && isset($_POST['push']) && isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role=="EMPLOYEE"){
    Service::change($_GET['edit'], $data['service_name'], $data['service_price']);
}

//Обработка нажатия Добавить
if(!isset($_GET['edit']) && isset($_POST['push']) && isset($_SESSION['logged_user']) && unserialize($_SESSION['logged_user'])->user_role=="EMPLOYEE"){
    $service = new Service($data['service_name'], $data['service_price']);
    $service->add();
}
    
Service::displayForm();
Service::displayTable();
?>