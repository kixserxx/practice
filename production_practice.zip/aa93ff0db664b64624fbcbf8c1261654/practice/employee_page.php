<?php
require_once 'classes/DB.php';
require_once 'classes/Inter.php';
require_once 'classes/User.php';
?>

<meta charset="utf-8">

<?php
$data = $_POST;
$db = new DB;

Inter::head();
//Вывод таблицы дизайнеров
User::displayDesignerTable();
?>