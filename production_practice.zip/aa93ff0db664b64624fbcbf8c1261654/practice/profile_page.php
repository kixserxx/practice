<?php
require_once 'classes/DB.php';
require_once 'classes/Inter.php';
require_once 'classes/User.php';
?>
<meta charset="utf-8">
<?php
$data = $_POST;
$db = new DB;

Inter::head();
User::displayForm();

//Обработка нажатия Изменить в профиле пользрвателя
if(isset($data['push'])){
    User::change(unserialize($_SESSION['logged_user'])->getId(), $data['user_name'], $data['user_login'], $data['user_password']);
    $temp_role = unserialize($_SESSION['logged_user'])->user_role;
    $_SESSION['logged_user'] = serialize(new User($data['user_name'], $temp_role, $data['user_login'], ""));
}
?>