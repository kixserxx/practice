<?php 

$data = $_POST;

echo '<link href="css/edit_form.css" rel="stylesheet">
<div class="edit-page">
  <div class="edit-form">
    <form class="login-form" action="registration.php"  method="POST">
        <input type="text" placeholder="ФИО" name="user_name" value="'.@$data['user_name'].'"/>
      <input type="text" placeholder="Логин" name="user_login" value="'.@$data['user_login'].'"/>
      <input type="password" placeholder="Пароль" name="user_password" value="'.@$data['user_password'].'"/>
      <select name="user_role">
          <option value="CUSTOMER">Заказчик</option>
          <option value="EMPLOYEE">Дизайнер</option>
      </select>
      <button type="submit" name="do_reg">Зарегистрироваться</button><br><br>
      <span>Есть аккаунт? <a href="index.php">Войти</a></span>
    </form>
  </div>
</div>';
?>