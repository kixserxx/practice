<?php

echo "<script>
onload = function ()
{
for (var lnk = document.links, j = 0; j < lnk.length; j++)
if (lnk [j].href == document.URL) lnk [j].style.cssText = 'color:#003049; border:0px solid #000';
}
</script>";
if (isset($_SESSION['logged_user'])){
    echo '<link href="css/menu.css" rel="stylesheet">
            <div class="nav-scroller">
              <nav class="nav-scroller__items">
                <a class="nav-scroller__item">Пользователь: '.unserialize($_SESSION['logged_user'])->user_name.'</a>
                <a class="nav-scroller__item" href="index.php">Заказы</a>';
                if(isset($_SESSION['logged_user']))
                    echo '<a class="nav-scroller__item" href="profile_page.php">Профиль</a>';
                echo '<a class="nav-scroller__item" href="service_page.php">Услуги</a>
                <a class="nav-scroller__item" href="employee_page.php">Дизайнеры</a>
                <a class="nav-scroller__item" href="logout.php">Выйти</a>';
                
        echo '</nav>
        </div>';
}
?>