<?php 

$data = $_POST;

echo '<link href="css/login_form.css" rel="stylesheet">
<div class="login-page">
  <div class="form">
    <form class="login-form" action="index.php"  method="POST">
      <input type="text" placeholder="Логин" name="user_login" value="'.@$data['user_login'].'"/>
      <input type="password" placeholder="Пароль" name="user_password" value="'.@$data['user_password'].'"/>
      <button type="submit" name="do_login">Войти</button><br><br>
      <span>Ещё нет аккаунта? <a href="registration.php">Зарегистрироваться</a></span>
    </form>
  </div>
</div>';
?>