<?php

echo "<!DOCTYPE html><html>
        <head><title>Студия дизайна</title></head>
        <body>";
        echo "<link href='css/head.css' rel='stylesheet'>";
        echo "<div class='wrapper'>";
        include 'menu.php';
        echo '<div class="content">';
        
?>