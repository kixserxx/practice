<?php
require_once 'classes/DB.php';
require_once 'classes/Inter.php';
require_once 'classes/User.php';
?>
<meta charset="utf-8">
<?php
$data = $_POST;
$db = new DB;
Inter::head();
Inter::regForm();
//Обработка нажатия Зарегестрироваться
if (isset($data['do_reg'])) {
	$user = new User($data['user_name'], $data['user_role'], $data['user_login'], $data['user_password']);
	$user->add();
	echo "Вы успешно зарегистрированы! Перейти ко <a href='index.php'>входу</a>.";
}
?>